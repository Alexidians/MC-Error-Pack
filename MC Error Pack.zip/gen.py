import sys
import subprocess

def install_module(module_name):
    """Install a Python module using pip."""
    print(f"Installing {module_name}...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", module_name])

# Ensure required modules are installed
try:
    import easygui
except ImportError:
    install_module('easygui')
    import easygui

try:
    from PIL import Image
except ImportError:
    install_module('Pillow')
    from PIL import Image

try:
    import tqdm
except ImportError:
    install_module('tqdm')
    import tqdm

import json
import os
import shutil
import zipfile
import uuid
from tqdm import tqdm
from PIL import Image
import easygui
import random

# Define paths for shaders and fonts
shaders = {
    "Wobbly World": 'shaders/wobbly_world.glsl',
    "Circular World": 'shaders/circular_world.glsl'
}
lights = {
    "Full Light": 'shaders/full_light.glsl',
    "Error Light": 'shaders/error_light.glsl',
    "No Light": 'shaders/no_light.glsl'
}
texture_path = 'textures/error_block.png'
texture2_path = 'textures/transparent.png'
texture3_path = 'textures/black.png'

# Font paths in the resource pack
font_files = {
    "accented": "assets/minecraft/textures/font/accented.png",
    "ascii": "assets/minecraft/textures/font/ascii.png",
    "ascii sga": "assets/minecraft/textures/font/ascii_sga.png",
    "asciillager": "assets/minecraft/textures/font/asciillager.png",
    "nonlatin european": "assets/minecraft/textures/font/nonlatin_european.png"
}

# Paths for forcing fonts
force_font_files = {
    "Force Default": "assets/minecraft/fonts/default.json",
    "Force Alt": "assets/minecraft/fonts/alt.json",
    "Force IllagerAlt": "assets/minecraft/fonts/illageralt.json",
    "Force Uniform": "assets/minecraft/fonts/uniform.json"
}

def replace_json_text(data, replacement_char):
    """Recursively replace all string values in JSON data with the replacement character."""
    if isinstance(data, dict):
        for key in data:
            if isinstance(data[key], str):
                data[key] = replacement_char * len(data[key])
            elif isinstance(data[key], dict):
                data[key] = replace_json_text(data[key], replacement_char)
            elif isinstance(data[key], list):
                data[key] = replace_json_text(data[key], replacement_char)
    elif isinstance(data, list):
        for index in range(len(data)):
            if isinstance(data[index], str):
                data[index] = replacement_char * len(data[index])
            elif isinstance(data[index], dict):
                data[index] = replace_json_text(data[index], replacement_char)
            elif isinstance(data[index], list):
                data[index] = replace_json_text(data[index], replacement_char)
    return data

def replace_text_characters(file_path, replacement_char):
    """Replace all characters in the text file with the specified replacement character."""
    if not os.path.exists(file_path):
        print(f"Text file {file_path} does not exist.")
        return

    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        with open(file_path, 'w', encoding='utf-8') as file:
            # Replace entire content of the file with the replacement character
            for line in lines:
                file.write(replacement_char * len(line))
    except Exception as e:
        print(f"Failed to replace text in {file_path}: {e}")

def apply_shader(shader_path, target_dir):
    """Apply the specified shader to the resource pack."""
    shaders_dir = os.path.join(target_dir, "assets", "minecraft", "shaders", "program")
    os.makedirs(shaders_dir, exist_ok=True)
    shutil.copy(shader_path, os.path.join(shaders_dir, os.path.basename(shader_path)))
    print(f"Applied shader: {shader_path}")

def apply_texture_to_fonts(texture_path, selected_fonts, temp_dir):
    """Apply the error texture to the selected font files."""
    texture_image = Image.open(texture_path).convert('RGBA')
       
    font_files_list = [os.path.join(temp_dir, font_files.get(font_key)) for font_key in selected_fonts if font_files.get(font_key)]
    
    with tqdm(total=len(font_files_list), desc="Applying texture to fonts", unit='font') as pbar:
        for font_path in font_files_list:
            if os.path.exists(font_path):
                try:
                    with Image.open(font_path).convert('RGBA') as font_img:
                        error_texture_resized = texture_image.resize(font_img.size, Image.ANTIALIAS)
                        error_texture_resized.save(font_path)
                except Exception as e:
                    print(f"Failed to apply texture to font {font_path}: {e}")
            else:
                print(f"Font file {font_path} does not exist.")
            pbar.update(1)
                
def apply_text_modifications(temp_dir, options):
    """Apply text modifications based on selected options."""
    replacement_char = ''  # Character to replace text with

    if options.get("Affect languages"):
        lang_dir = os.path.join(temp_dir, 'assets', 'minecraft', 'lang')
        json_files = [f for f in os.listdir(lang_dir) if f.endswith('.json')]
        with tqdm(total=len(json_files), desc="Replacing text in language files", unit='file') as pbar:
            for file in json_files:
                target_path = os.path.join(lang_dir, file)
                
                # Read the JSON file
                with open(target_path, 'r', encoding='utf-8') as f:
                    json_data = json.load(f)
                
                # Modify the JSON content
                modified_json_data = replace_json_text(json_data, replacement_char)
                
                # Write the modified JSON content back to the file
                with open(target_path, 'w', encoding='utf-8') as f:
                    json.dump(modified_json_data, f, ensure_ascii=False, indent=4)
                
                pbar.update(1)
    
    if options.get("Affect end text"):
        target_path = os.path.join(temp_dir, 'assets', 'minecraft', 'texts', 'end.txt')
        if os.path.exists(target_path):
            replace_text_characters(target_path, replacement_char)
    
    if options.get("Affect splash text"):
        target_path = os.path.join(temp_dir, 'assets', 'minecraft', 'texts', 'splashes.txt')
        if os.path.exists(target_path):
            replace_text_characters(target_path, replacement_char)
    
    if options.get("Affect credits"):
        target_path = os.path.join(temp_dir, 'assets', 'minecraft', 'texts', 'credits.json')
        if os.path.exists(target_path):
            with open(target_path, 'r+', encoding='utf-8') as file:
                data = json.load(file)
                data = replace_json_text(data, replacement_char)
                file.seek(0)
                json.dump(data, file, ensure_ascii=False, indent=4)
                file.truncate()
                
def extract_zip(zip_path, extract_to):
    """Extract the ZIP file to the specified directory."""
    print(f"Extracting ZIP file \"{zip_path}\" to \"{extract_to}\"...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        file_list = zip_ref.namelist()
        with tqdm(total=len(file_list), desc="Extracting ZIP", unit='file') as pbar:
            for file in file_list:
                zip_ref.extract(file, extract_to)
                pbar.update(1)
    print("Extraction complete.")

def zip_directory(directory_path, zip_path):
    """Zip the contents of a directory."""
    print(f"Creating ZIP file: {zip_path}")
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        files = []
        for root, _, filenames in os.walk(directory_path):
            for file in filenames:
                files.append(os.path.join(root, file))
        
        with tqdm(total=len(files), desc="Zipping files", unit='file') as pbar:
            for file in files:
                zipf.write(file, os.path.relpath(file, directory_path))
                pbar.update(1)
    print("ZIP file created.")

def apply_force_font(temp_dir, force_font_choice):
    """Replace all font files with the content of the selected force font file."""
    force_font_path = force_font_files.get(force_font_choice)
    if force_font_path and os.path.exists(force_font_path):
        with open(force_font_path, 'r') as src_file:
            force_font_data = src_file.read()
        
        font_files_dir = os.path.join(temp_dir, 'assets', 'minecraft', 'textures', 'font')
        font_files_list = os.listdir(font_files_dir)
        
        with tqdm(total=len(font_files_list), desc="Applying force font", unit='font') as pbar:
            for font_file in font_files_list:
                font_file_path = os.path.join(font_files_dir, font_file)
                with open(font_file_path, 'w') as dest_file:
                    dest_file.write(force_font_data)
                    pbar.update(1)
    else:
        print(f"Selected force font file \"{force_font_path}\" does not exist.")

def apply_texture_to_directory(texture_path, target_directory):
    """Apply the error texture to all files in the target directory recursively."""
    def process_directory(directory):
        """Process all files and directories within the given directory."""
        items = os.listdir(directory)
        total_items = len(items)

        # Progress bar for the current directory
        with tqdm(total=total_items, desc=f"Processing: {directory}", unit='item') as dir_pbar:
            for item in items:
                item_path = os.path.join(directory, item)
                if os.path.isfile(item_path):
                    # Apply texture to file
                    print(f"Processing file: {item_path}")
                    try:
                        with Image.open(item_path).convert('RGBA') as img:
                            with Image.open(texture_path).convert('RGBA') as tex_img:
                                tex_img_resized = tex_img.resize(img.size, Image.ANTIALIAS)
                                tex_img_resized.save(item_path)
                                print(f"Processed: {item_path}")
                    except Exception as e:
                        print(f"Failed to apply texture to {item_path}: {e}")
                elif os.path.isdir(item_path):
                    # Recursively process subdirectory
                    process_directory(item_path)

                dir_pbar.update(1)

    # Start processing from the target directory
    process_directory(target_directory)

def replace_elements_in_json_files(base_directory):
    models_directory = 'models/blockitem/corrupt'  # Hardcoded models directory

    # Ensure the models directory exists
    if not os.path.isdir(models_directory):
        print(f"Error: Models directory {models_directory} does not exist.")
        return

    # Load all model files from the models directory
    model_files = [f for f in os.listdir(models_directory) if os.path.isfile(os.path.join(models_directory, f)) and f.endswith('.json')]

    if not model_files:
        print(f"Error: No JSON model files found in the models directory {models_directory}.")
        return

    # Function to process files and directories recursively
    def process_directory(directory, progress_bar):
        items = os.listdir(directory)
        total_items = len(items)
        
        for item in items:
            item_path = os.path.join(directory, item)
            
            if os.path.isdir(item_path):
                # If it's a directory, process it recursively
                process_directory(item_path, progress_bar)
            elif os.path.isfile(item_path) and item_path.endswith('.json'):
                # If it's a JSON file, process it
                print(f"Processing file: {item_path}")

                try:
                    with open(item_path, 'r') as file:
                        data = json.load(file)

                    # Choose a random model file
                    random_model_file = random.choice(model_files)
                    random_model_path = os.path.join(models_directory, random_model_file)
                    
                    with open(random_model_path, 'r') as model_file:
                        model_data = json.load(model_file)

                    model_elements = model_data.get('elements', [])

                    # Replace only the 'elements' section
                    if 'elements' in data:
                        data['elements'] = model_elements

                        # Write the modified data back to the file
                        with open(item_path, 'w') as file:
                            json.dump(data, file, indent=4)
                    else:
                        print(f"No 'elements' key found in model file {item_path}. Skipping replacement.")
                
                except json.JSONDecodeError:
                    print(f"Error decoding JSON in file {item_path}.")
                except Exception as e:
                    print(f"An error occurred with file {item_path}: {e}")

                progress_bar.update(1)  # Update progress bar for each processed file

    # Start processing from the base directory
    total_files = sum([len(files) for r, d, files in os.walk(base_directory)])
    with tqdm(total=total_files, desc='Processing files') as progress_bar:
        process_directory(base_directory, progress_bar)

def apply_mcmeta_corruption(target_directory, options):
    """Corrupt `.mcmeta` files in the target directory recursively based on options."""
    
    # Extract animation option from the options dictionary
    anim_option = options.get("animations", "unanimate")
    
    # Exit the function immediately if the option is "keep"
    if anim_option == "keep":
        print("The 'keep' option is specified. No changes will be made.")
        return

    def generate_random_animation(texture_path):
        """Generate a random animation configuration within the bounds of the original texture."""
        try:
            with Image.open(texture_path) as img:
                texture_width, texture_height = img.size
                num_frames = random.randint(1, 10)  # Random number of frames between 1 and 10
                frametime = random.randint(1, 10)  # Random frametime between 1 and 10

                # Generate valid frame indices within the bounds of the texture
                frames = list(range(num_frames))  # Frame indices from 0 to num_frames-1
                random.shuffle(frames)  # Shuffle frames to create a random sequence

                return {
                    "frametime": frametime,
                    "frames": frames
                }
        except Exception as e:
            print(f"Failed to generate animation due to: {e}")
            return {
                "frametime": 1,
                "frames": [0]  # Default to a single frame if there’s an error
            }

    def process_directory(directory):
        """Process all files and directories within the given directory."""
        items = os.listdir(directory)
        total_items = len(items)

        # Progress bar for the current directory
        with tqdm(total=total_items, desc=f"Processing: {directory}", unit='item') as dir_pbar:
            for item in items:
                item_path = os.path.join(directory, item)
                if os.path.isfile(item_path):
                    # Corrupt .mcmeta files if present
                    if item_path.lower().endswith('.mcmeta'):
                        print(f"Processing .mcmeta file: {item_path}")
                        try:
                            with open(item_path, 'r', encoding='utf-8') as file:
                                data = json.load(file)
                                
                            # Determine if there is an associated texture
                            texture_path = item_path.rsplit('.', 1)[0] + '.png'
                            
                            # Apply the chosen animation option
                            if anim_option == "unanimate":
                                # Remove animation data
                                data.pop('animation', None)
                            elif anim_option == "reanimate":
                                # Randomize existing animation if it exists
                                if 'animation' in data:
                                    data['animation'] = generate_random_animation(texture_path)
                            elif anim_option == "setanim":
                                # Set new random animation data
                                data['animation'] = generate_random_animation(texture_path)
                            
                            # Save changes
                            with open(item_path, 'w', encoding='utf-8') as file:
                                json.dump(data, file, indent=4)
                                
                            print(f"Processed: {item_path}")
                        except Exception as e:
                            print(f"Failed to apply corruption to {item_path}: {e}")
                elif os.path.isdir(item_path):
                    # Recursively process subdirectory
                    process_directory(item_path)

                dir_pbar.update(1)

    # Start processing from the target directory
    process_directory(target_directory)

def select_options_mcmeta(existing_mcmeta_options=None):
    """Show a GUI to select where and what to modify in the .mcmeta options block, always returning the complete block."""
    
    # Initialize the options block with "keep" for all texture types if no existing options are provided
    if existing_mcmeta_options is None:
        mcmeta_options = {"textures": {"items": {texture_type: {"animations": "keep"} for texture_type in
                                                   ["entity", "block", "environment", "gui", "item", "map", 
                                                    "misc", "mob_effect", "particle", "trims", "colormap"]}}}
    else:
        mcmeta_options = existing_mcmeta_options.copy()
    
    # Ask user which part of the .mcmeta options they want to modify
    modification_section = easygui.buttonbox(
        "Select the part of the .mcmeta options to modify:",
        choices=["textures"]
    )
    
    if modification_section == "textures":
        # Handle texture options
        texture_types = ["entity", "block", "environment", "gui", "item", "map", 
                         "misc", "mob_effect", "particle", "trims", "colormap"]
        
        # Ensure we have a section for textures
        if "textures" not in mcmeta_options:
            mcmeta_options["textures"] = {"items": {}}
        if "items" not in mcmeta_options["textures"]:
            mcmeta_options["textures"]["items"] = {}
        
        # Process each texture type
        for texture_type in texture_types:
            anim_option = easygui.buttonbox(
                f"Select animation option for {texture_type}:",
                choices=["keep", "unanimate", "reanimate", "setanim"]
            )
            
            # If user cancels or provides no valid option, default to "keep"
            if anim_option is None:
                anim_option = "keep"
                easygui.msgbox(f"No valid animation option selected for {texture_type}. Defaulting to 'keep'.")
            
            # Update the options block with user input or default value
            mcmeta_options["textures"]["items"][texture_type] = {"animations": anim_option}
    
    else:
        # If no valid section is selected, retain existing options
        easygui.msgbox("No valid section selected. Retaining existing options.")
    
    return mcmeta_options

def main():
    # Multi-input box for selecting options
    msg = "Select the options for error modifications:"
    choices = {
        "textures": {
            "Affect entities": False,
            "Affect blocks": False,
            "Affect environment": False,
            "Affect GUIs": False,
            "Affect items": False,
            "Affect maps": False,
            "Affect miscellaneous textures": False,
            "Affect mob effects": False,
            "Affect particles": False,
            "Affect trims": False,
            "Affect Armor": False,
            "Affect colormaps": False,
            "Blackify": False
        },
        "text": {
            "Affect languages": False,
            "Affect end text": False,
            "Affect splash text": False,
            "Affect credits": False
        },
        "fonts": {
            "Errorify Fonts": [],  # List of fonts to errorify
            "Delete Fonts": [],  # List of fonts to delete
            "Force Font": None,  # Force font option
        },
        "rendering": {
            "Light": [],  # List of light options
            "Shaders": []  # List of shaders
        },
        "models": {
            "Affect items": False,
            "Affect blocks": False
        },
        "mcmeta": None
    }

    while True:
        option = easygui.buttonbox("Select an option", choices=["Textures", "Text", "Fonts", "Rendering", "Models", "Start Errorifying"], 
                                   default_choice="Start Errorifying")

        if option == "Textures":
            textures_options = easygui.multchoicebox(
                msg, choices=list(choices["textures"].keys()),
                preselect=[key for key, value in choices["textures"].items() if value]
            )
            for option in choices["textures"]:
                choices["textures"][option] = option in textures_options

        elif option == "Text":
            text_options = easygui.multchoicebox(
                msg, choices=list(choices["text"].keys()), 
                preselect=[key for key, value in choices["text"].items() if value]
            )
            for option in choices["text"]:
                choices["text"][option] = option in text_options

        elif option == "Fonts":
            font_category = easygui.buttonbox("Select a font category", choices=["Errorify Fonts", "Force Font", "Delete Fonts"])

            if font_category == "Errorify Fonts":
                errorify_options = easygui.multchoicebox(
                    "Select fonts to errorify", choices=list(font_files.keys()),
                    preselect=list(choices["fonts"]["Errorify Fonts"])
                )
                choices["fonts"]["Errorify Fonts"] = errorify_options

            elif font_category == "Force Font":
                force_font_choice = easygui.choicebox("Select a font to force", choices=["Force Default", "Force Alt", "Force IllagerAlt", "Force Uniform"])
                choices["fonts"]["Force Font"] = force_font_choice

            elif font_category == "Delete Fonts":
                delete_options = easygui.multchoicebox(
                    "Select fonts to delete", choices=list(font_files.keys()),
                    preselect=list(choices["fonts"]["Delete Fonts"])
                )
                choices["fonts"]["Delete Fonts"] = delete_options

        elif option == "Rendering":
            rendering_option = easygui.buttonbox("Select Rendering option", choices=["Shaders", "Light"])

            if rendering_option == "Shaders":
                shader_choices = easygui.multchoicebox("Select shaders to apply", choices=list(shaders.keys()))
                choices["rendering"]["Shaders"] = shader_choices

            elif rendering_option == "Light":
                light_choices = easygui.multchoicebox("Select light options", choices=list(lights.keys()))
                choices["rendering"]["Light"] = light_choices
        elif option == "Models":
            models_options = easygui.multchoicebox(
                msg, choices=list(choices["models"].keys()),
                preselect=[key for key, value in choices["models"].items() if value]
            )
            for option in choices["models"]:
                choices["models"][option] = option in models_options
        elif option == "mcmeta":
            choices["mcmeta"] = select_choices_mcmeta(choices["mcmeta"])
        elif option == "Start Errorifying":
            break

    # Get file paths for extraction and saving
    zip_path = easygui.fileopenbox("Select the resource pack ZIP file", filetypes=["*.zip"])
    if not zip_path:
        print("No resource pack ZIP file selected. Exiting.")
        return

    temp_dir = os.path.join("temp", str(uuid.uuid4()))
    os.makedirs(temp_dir, exist_ok=True)

    # Extract the ZIP file
    extract_zip(zip_path, temp_dir)

    # Apply shaders based on selected shader choices
    shader_choices = choices["rendering"].get("Shaders", [])
    for shader_choice in shader_choices:
        shader_path = shaders.get(shader_choice)
        if shader_path:
            apply_shader(shader_path, temp_dir)

    # Apply light effects based on selected light choices
    light_choices = choices["rendering"].get("Light", [])
    for light_choice in light_choices:
        shader_path = lights.get(light_choice)
        if shader_path:
            apply_shader(shader_path, temp_dir)

    texture_paths = {
        "Affect entities": "assets/minecraft/textures/entity",
        "Affect blocks": "assets/minecraft/textures/block",
        "Affect environment": "assets/minecraft/textures/environment",
        "Affect GUIs": "assets/minecraft/textures/gui",
        "Affect items": "assets/minecraft/textures/item",
        "Affect maps": "assets/minecraft/textures/map",
        "Affect miscellaneous textures": "assets/minecraft/textures/misc",
        "Affect mob effects": "assets/minecraft/textures/mob_effect",
        "Affect particles": "assets/minecraft/textures/particle",
        "Affect trims": "assets/minecraft/textures/trims",
        "Affect Armor": "assets/minecraft/textures/models/armor",
        "Affect colormaps": "assets/minecraft/textures/colormap"
    }

    for option, dir_path in texture_paths.items():
        if choices["textures"].get(option):
            full_path = os.path.join(temp_dir, dir_path)
            if os.path.exists(full_path):
                apply_texture_to_directory(texture_path, full_path)
            else:
                print(f"Directory {full_path} does not exist.")

    if choices["textures"].get("Blackify", False):
        apply_texture_to_directory(texture3_path, os.path.join(temp_dir, "assets/minecraft/textures"))

    model_paths = {
        "Affect items": "assets/minecraft/models/item",
        "Affect blocks": "assets/minecraft/models/block"
    }

    for option, dir_path in model_paths.items():
        if choices["models"].get(option):
            full_path = os.path.join(temp_dir, dir_path)
            if os.path.exists(full_path):
                replace_elements_in_json_files(full_path)
            else:
                print(f"Directory {full_path} does not exist.")
    
    # Apply text modifications
    apply_text_modifications(temp_dir, choices["text"])

    # Apply texture to fonts
    print("Applying font modifications")
    if choices["fonts"]["Errorify Fonts"]:
        print("Errorifying Fonts")
        apply_texture_to_fonts(texture_path, choices["fonts"]["Errorify Fonts"], temp_dir)

    if choices["fonts"]["Delete Fonts"]:
        print("Deleting Fonts")
        apply_texture_to_fonts(texture2_path, choices["fonts"]["Delete Fonts"], temp_dir)

    # Force specific font
    if choices["fonts"]["Force Font"]:
        print("Setting Force Font ", choices["fonts"]["Force Font"])
        force_font = choices["fonts"]["Force Font"]
        apply_force_font(temp_dir, force_font)
    
    print("Applying mcmeta modifications...")
    print("Applying mcmeta modifications for textures")
    if choices["mcmeta"] is not None:
        for texture_type, options in options["mcmeta"].get("textures").items():
            print("Applying mcmeta modification for ", texture_type, " textures")
            apply_mcmeta_corruption(os.path.join(temp_dir, "assets/minecraft/textures/", texture_type), options)

    # Create ZIP file from temp directory
    output_zip = easygui.filesavebox("Save the modified resource pack as", default=f"Errorified_{uuid.uuid4().hex[:8]}.zip", filetypes=["*.zip"])
    if not output_zip:
        print("No save location specified. Exiting.")
        return

    zip_directory(temp_dir, output_zip)

    # Clean up temporary directory
    shutil.rmtree(temp_dir)
    print(f"Errorified resource pack saved as {output_zip}")

if __name__ == "__main__":
    main()
