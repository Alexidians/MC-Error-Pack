import os
import uuid
import zipfile
import shutil
from tqdm import tqdm
import easygui
from pathlib import Path

# Function to select file with easygui file dialog
def select_file():
    file_path = easygui.fileopenbox(
        title="Select a .zip or .jar file",
        filetypes=["*.zip", "*.jar"]
    )
    if not file_path:
        raise ValueError("No file selected.")
    return file_path

# Function to select save path with easygui file dialog
def select_save_path():
    save_path = easygui.filesavebox(
        title="Save as...",
        default="output.zip",
        filetypes=["*.zip"]
    )
    if not save_path:
        raise ValueError("No save path selected.")
    return save_path

def main():
    # Step 1: Select the input file and unzip it
    input_file = select_file()
    temp_dir = Path(f"tmp/{uuid.uuid4()}")
    temp_dir.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(input_file, 'r') as zip_ref:
        zip_contents = zip_ref.namelist()
        with tqdm(total=len(zip_contents), desc="Extracting files") as pbar:
            for file in zip_contents:
                zip_ref.extract(file, temp_dir)
                pbar.update(1)

    # Step 2: Remove everything from data folder except datapacks
    data_folder = temp_dir / "data"
    if data_folder.exists():
        for item in data_folder.iterdir():
            if item.name != "datapacks":
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()

    # Step 3: Loop through datapacks and delete data folders within
    datapacks_folder = data_folder / "datapacks"
    if datapacks_folder.exists():
        datapack_folders = list(datapacks_folder.iterdir())
        with tqdm(total=len(datapack_folders), desc="Processing datapacks") as pbar:
            for pack in datapack_folders:
                if pack.is_dir():
                    for sub_item in pack.glob("**/data"):
                        if sub_item.is_dir():
                            shutil.rmtree(sub_item)
                pbar.update(1)

    # Step 4: Zip the contents and save using save dialog
    output_file = select_save_path()
    with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as zip_out:
        for root, dirs, files in os.walk(temp_dir):
            for file in files:
                file_path = Path(root) / file
                zip_out.write(file_path, file_path.relative_to(temp_dir))
                tqdm.write(f"Adding {file_path}")

    # Cleanup
    shutil.rmtree(temp_dir)
    print("Operation completed successfully.")

if __name__ == "__main__":
    main()
